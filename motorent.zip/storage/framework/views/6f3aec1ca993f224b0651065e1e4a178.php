<?php $__env->startSection('content'); ?>
<div class="container">
  <h2>Teeth Panorama Cases</h2>
  <table id="casesTable" class="display table table-bordered">
      <thead>
          <tr>
              <th>ID</th>
              <th>Case Name</th>
              <th>Doctor</th>
              
              <th>Created At</th>
              <th>Actions</th>
          </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($case->id); ?></td>
                  <td><?php echo e($case->name); ?></td>
                  <td><?php echo e($case->doctor->name); ?></td>
                  
                  <td><?php echo e($case->created_at->format('Y-m-d')); ?></td>
                  <td><a href="#" class="btn btn-info btn-sm">View</a></td>
              </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
  $(document).ready(function () {
        $('#casesTable').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>

</style> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/medicscan/resources/views/admin/sections/cases/cases.blade.php ENDPATH**/ ?>