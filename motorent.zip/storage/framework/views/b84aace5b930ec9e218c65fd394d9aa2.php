<!DOCTYPE html>
    <html lang="en">
      <head>
        <base href="./">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
        <meta name="description" content="CoreUI - Open Source Bootstrap Admin Template">
        <meta name="author" content="Łukasz Holeczek">
        <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,jQuery,CSS,HTML,RWD,Dashboard">
        <title>CoreUI Free Bootstrap Admin Template</title>
        <link rel="apple-touch-icon" sizes="57x57" href=<?php echo e(asset("/public/admin/assets/favicon/apple-icon-57x57.png")); ?>>
        <link rel="apple-touch-icon" sizes="60x60" href=<?php echo e(asset("/public/admin/assets/favicon/apple-icon-60x60.png")); ?>>
        <link rel="apple-touch-icon" sizes="72x72" href=<?php echo e(asset("/public/admin/assets/favicon/apple-icon-72x72.png")); ?>>
        <link rel="apple-touch-icon" sizes="76x76" href=<?php echo e(asset("/public/admin/assets/favicon/apple-icon-76x76.png")); ?>>
        <link rel="apple-touch-icon" sizes="114x114" href=<?php echo e(asset("/public/admin/assets/favicon/apple-icon-114x114.png")); ?>>
        <link rel="apple-touch-icon" sizes="120x120" href=<?php echo e(asset("/public/admin/assets/favicon/apple-icon-120x120.png")); ?>>
        <link rel="apple-touch-icon" sizes="144x144" href=<?php echo e(asset("/public/admin/assets/favicon/apple-icon-144x144.png")); ?>>
        <link rel="apple-touch-icon" sizes="152x152" href=<?php echo e(asset("/public/admin/assets/favicon/apple-icon-152x152.png")); ?>>
        <link rel="apple-touch-icon" sizes="180x180" href=<?php echo e(asset("/public/admin/assets/favicon/apple-icon-180x180.png")); ?>>
        <link rel="icon" type="image/png" sizes="192x192" href=<?php echo e(asset("/public/admin/assets/favicon/android-icon-192x192.png")); ?>>
        <link rel="icon" type="image/png" sizes="32x32" href=<?php echo e(asset("/public/admin/assets/favicon/favicon-32x32.png")); ?>>
        <link rel="icon" type="image/png" sizes="96x96" href=<?php echo e(asset("/public/admin/assets/favicon/favicon-96x96.png")); ?>>
        <link rel="icon" type="image/png" sizes="16x16" href=<?php echo e(asset("/public/admin/assets/favicon/favicon-16x16.png")); ?>>
        <link rel="manifest" href=<?php echo e(asset("/public/admin/assets/favicon/manifest.json")); ?>>
        <meta name="msapplication-TileColor" content="#ffffff">
        <meta name="msapplication-TileImage" content=<?php echo e(asset("/public/admin/assets/favicon/ms-icon-144x144.png")); ?>>
        <meta name="theme-color" content="#ffffff">
        <!-- Vendors styles-->
        <link rel="stylesheet" href=<?php echo e(asset("/public/admin/vendors/simplebar/css/simplebar.css")); ?>>
        <link rel="stylesheet" href=<?php echo e(asset("/public/admin/css/vendors/simplebar.css")); ?>>
        <!-- Main styles for this application-->
        <link href=<?php echo e(asset("/public/admin/css/style.css")); ?> rel="stylesheet">
        <!-- We use those styles to show code examples, you should remove them in your application.-->
        <link href=<?php echo e(asset("/public/admin/css/examples.css")); ?> rel="stylesheet">
        <script src=<?php echo e(asset("/public/admin/js/config.js")); ?>></script>
        <script src=<?php echo e(asset("/public/admin/js/color-modes.js")); ?>></script>
      </head>
      <body>
        <div class="bg-body-tertiary min-vh-100 d-flex flex-row align-items-center">
          <div class="container">
            <div class="row justify-content-center">
              <div class="col-lg-8">
                <div class="card-group d-block d-md-flex row">
                  <div class="card col-md-7 p-4 mb-0">
                    <div class="card-body">
                      <form method="POST" action="<?php echo e(route('admin.login.post')); ?>">
                        <?php echo csrf_field(); ?>
                      <h1>Login</h1>
                      <p class="text-body-secondary">Sign In to your account</p>
                      <div class="input-group mb-3"><span class="input-group-text">
                          <svg class="icon">
                            <use xlink:href=<?php echo e(url('/public/admin/vendors/@coreui/icons/svg/free.svg')); ?>#cil-user></use>
                          </svg></span>
                        <input class="form-control" name="email"  type="email" placeholder="Email">
                      </div>
                      <div class="input-group mb-4"><span class="input-group-text">
                          <svg class="icon">
                            <use xlink:href=<?php echo e(url('/public/admin/vendors/@coreui/icons/svg/free.svg')); ?>#cil-lock-locked></use>
                          </svg></span>
                        <input class="form-control"  name="password"  type="password" placeholder="Password">
                      </div>
                      <div class="row">
                        <div class="col-6">
                          <button class="btn btn-primary px-4"  type="submit">Login</button>
                        </div>
                        <div class="col-6 text-end">
                          <button class="btn btn-link px-0" type="button">Forgot password?</button>
                        </div>
                      </div>
                    </form>
                    </div>
                  </div>
                  <div class="card col-md-5 text-white bg-primary py-5">
                    <div class="card-body text-center">
                      <div>
                        <h2>Sign up</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                        <button class="btn btn-lg btn-outline-light mt-3" type="button">Register Now!</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- CoreUI and necessary plugins-->
        <script src=<?php echo e(asset("vendors/@coreui/coreui/js/coreui.bundle.min.js")); ?>></script>
        <script src=<?php echo e(asset("vendors/simplebar/js/simplebar.min.js")); ?>></script>
        <script>
          const header = document.querySelector('header.header');
    
          document.addEventListener('scroll', () => {
            if (header) {
              header.classList.toggle('shadow-sm', document.documentElement.scrollTop > 0);
            }
          });
        </script>
        <script>
        </script>
    
      </body>
    </html><?php /**PATH /var/www/html/medicscan/resources/views/admin/login.blade.php ENDPATH**/ ?>