<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('admin.case.store')); ?>" enctype="multipart/form-data" class="row g-3">
  <?php echo csrf_field(); ?>
  <div class="col-md-6">
      <label class="form-label">Case Name</label>
      <input type="text" name="case_name" class="form-control" required>
  </div>

  <div class="col-12">
      <label class="form-label">Notes</label>
      <textarea name="notes" class="form-control"></textarea>
  </div>
  <?php $__currentLoopData = ['panorama', 'periapical', 'ortho', 'ct']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="mb-3">
      <label class="form-label"><?php echo e(ucfirst($type)); ?> Scan Images</label>
      <input type="file" class="form-control scan-image-input" name="<?php echo e($type); ?>_images[]" data-type="<?php echo e($type); ?>" multiple accept="image/*">

      <div id="preview-<?php echo e($type); ?>" class="mt-2 d-flex flex-wrap gap-2"></div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  

  <div class="col-12">
      <button type="submit" class="btn btn-primary">Save Case</button>
  </div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.querySelectorAll('.scan-image-input').forEach(input => {
    const previewContainer = document.getElementById(`preview-${input.dataset.type}`);
    const filesArray = [];

    input.addEventListener('change', function(event) {
        const newFiles = [...event.target.files];

        newFiles.forEach(file => {
            // Prevent duplicates
            if (!filesArray.includes(file)) {
                filesArray.push(file);

                const reader = new FileReader();
                reader.onload = function(e) {
                    const div = document.createElement('div');
                    div.classList.add('position-relative', 'm-2');

                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.classList.add('img-thumbnail');
                    img.style.width = '120px';
                    img.style.height = '120px';
                    img.style.objectFit = 'cover';

                    const removeBtn = document.createElement('button');
                    removeBtn.innerHTML = '&times;';
                    removeBtn.type = 'button';
                    removeBtn.classList.add('btn', 'btn-danger', 'btn-sm', 'position-absolute');
                    removeBtn.style.top = '5px';
                    removeBtn.style.right = '5px';

                    removeBtn.onclick = () => {
                        const index = filesArray.indexOf(file);
                        if (index > -1) {
                            filesArray.splice(index, 1);
                        }
                        div.remove();

                        // update input files
                        const dataTransfer = new DataTransfer();
                        filesArray.forEach(f => dataTransfer.items.add(f));
                        input.files = dataTransfer.files;
                    };

                    div.appendChild(img);
                    div.appendChild(removeBtn);
                    previewContainer.appendChild(div);
                };
                reader.readAsDataURL(file);
            }
        });

        // update input with all files so form submission includes everything
        const dataTransfer = new DataTransfer();
        filesArray.forEach(f => dataTransfer.items.add(f));
        input.files = dataTransfer.files;
    });
});
</script>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('styles'); ?>
<style>
    /* .scan-image-preview {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
    }
    .scan-image-preview img {
        width: 120px;
        height: 120px;
        object-fit: cover;
    } */
</style> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/medicscan/resources/views/admin/sections/cases/add_case.blade.php ENDPATH**/ ?>